"use client"

import LandingPage from "../page"

export default function SyntheticV0PageForDeployment() {
  return <LandingPage />
}