"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { CreditCard, Download, Menu, X } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { useState } from "react"

export default function LandingPage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <div className="min-h-screen bg-[#0A0C10]">
      {/* Navigation */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-[#0A0C10]/80 backdrop-blur-lg border-b border-white/10">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center space-x-2">
              <CreditCard className="h-6 w-6 text-blue-500" />
              <span className="font-bold text-white">CardVault</span>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              <Link href="#features" className="text-sm text-white/70 hover:text-white transition-colors">
                Features
              </Link>
              <Link href="#security" className="text-sm text-white/70 hover:text-white transition-colors">
                Security
              </Link>
              <Link href="#backup" className="text-sm text-white/70 hover:text-white transition-colors">
                Backup
              </Link>
              <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                <Download className="mr-2 h-4 w-4" />
                Download
              </Button>
            </nav>

            {/* Mobile Menu Button */}
            <button className="md:hidden text-white" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden py-4 border-t border-white/10">
              <nav className="flex flex-col space-y-4">
                <Link href="#features" className="text-sm text-white/70 hover:text-white transition-colors">
                  Features
                </Link>
                <Link href="#security" className="text-sm text-white/70 hover:text-white transition-colors">
                  Security
                </Link>
                <Link href="#backup" className="text-sm text-white/70 hover:text-white transition-colors">
                  Backup
                </Link>
                <Button className="bg-blue-600 hover:bg-blue-700 text-white w-full">
                  <Download className="mr-2 h-4 w-4" />
                  Download
                </Button>
              </nav>
            </div>
          )}
        </div>
      </header>

      <main className="pt-16">
        {/* Hero 1 - Quick Find */}
        <section id="features" className="py-20 md:py-32 relative overflow-hidden">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <div className="inline-block rounded-full bg-yellow-400/10 px-4 py-1.5 text-sm font-medium text-yellow-400">
                  Quick Access
                </div>
                <h2 className="text-4xl md:text-5xl font-bold text-white leading-tight">
                  Quickly find your cards, just like a virtual pocket
                </h2>
                <p className="text-lg text-white/70">
                  Access all your saved cards instantly with our intuitive interface. No more fumbling through physical
                  cards.
                </p>
                <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white">
                  Get Started
                </Button>
              </div>
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-yellow-400/20 to-transparent rounded-2xl blur-3xl -z-10" />
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/cards-RpRJmrH1Jzq3UGe0Jnqo33GIVHgWpi.png"
                  alt="Quick card access interface"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-2xl"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Hero 2 - Offline Security */}
        <section id="security" className="py-20 md:py-32 relative overflow-hidden bg-black/30">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="relative order-2 md:order-1">
                <div className="absolute inset-0 bg-gradient-to-r from-orange-400/20 to-transparent rounded-2xl blur-3xl -z-10" />
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/cards-RpRJmrH1Jzq3UGe0Jnqo33GIVHgWpi.png"
                  alt="Offline security features"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-2xl"
                />
              </div>
              <div className="space-y-6 order-1 md:order-2">
                <div className="inline-block rounded-full bg-orange-400/10 px-4 py-1.5 text-sm font-medium text-orange-400">
                  Offline Security
                </div>
                <h2 className="text-4xl md:text-5xl font-bold text-white leading-tight">
                  OFFLINE! Your cards stay with you, secure.
                </h2>
                <p className="text-lg text-white/70">
                  Your card data never leaves your device. Experience complete privacy with our offline-first approach.
                </p>
                <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white">
                  Learn More
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Hero 3 - Easy Addition */}
        <section className="py-20 md:py-32 relative overflow-hidden">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <div className="inline-block rounded-full bg-teal-400/10 px-4 py-1.5 text-sm font-medium text-teal-400">
                  Easy Addition
                </div>
                <h2 className="text-4xl md:text-5xl font-bold text-white leading-tight">
                  Quickly add a card once, save it FOREVER!
                </h2>
                <p className="text-lg text-white/70">
                  Adding new cards is a breeze. Our smart form automatically formats and validates card details as you
                  type.
                </p>
                <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white">
                  Try Now
                </Button>
              </div>
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-teal-400/20 to-transparent rounded-2xl blur-3xl -z-10" />
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/cards-RpRJmrH1Jzq3UGe0Jnqo33GIVHgWpi.png"
                  alt="Add new card interface"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-2xl"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Hero 4 - Backup */}
        <section id="backup" className="py-20 md:py-32 relative overflow-hidden bg-black/30">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="relative order-2 md:order-1">
                <div className="absolute inset-0 bg-gradient-to-r from-green-400/20 to-transparent rounded-2xl blur-3xl -z-10" />
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/cards-RpRJmrH1Jzq3UGe0Jnqo33GIVHgWpi.png"
                  alt="Backup and restore interface"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-2xl"
                />
              </div>
              <div className="space-y-6 order-1 md:order-2">
                <div className="inline-block rounded-full bg-green-400/10 px-4 py-1.5 text-sm font-medium text-green-400">
                  Encrypted Backup
                </div>
                <h2 className="text-4xl md:text-5xl font-bold text-white leading-tight">
                  Backup your cards, and restore it wherever you like
                </h2>
                <p className="text-lg text-white/70">
                  Never lose your card data with encrypted backups. Restore your cards on any device, securely.
                </p>
                <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white">
                  Start Backup
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Final CTA */}
        <section className="py-20 relative overflow-hidden">
          <div className="container mx-auto px-4">
            <Card className="bg-[#1A1D23] border-white/10 p-8 max-w-2xl mx-auto text-center">
              <h2 className="text-3xl font-bold text-white mb-4">Ready to Secure Your Cards?</h2>
              <p className="text-white/70 mb-6">
                Join thousands of users who trust our app for their card management needs.
              </p>
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white">
                <Download className="mr-2 h-5 w-5" />
                Download Now
              </Button>
            </Card>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/10 py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <CreditCard className="h-6 w-6 text-blue-500" />
              <span className="text-white font-bold">CardVault</span>
            </div>
            <p className="text-sm text-white/50">© {new Date().getFullYear()} CardVault. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

